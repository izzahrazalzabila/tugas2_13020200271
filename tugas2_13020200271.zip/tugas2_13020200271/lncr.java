//NIM           : 13020200271
//Nama          : Izzahra Zalzabila
// Tanggal/Hari : Selasa, 22 Maret 2022
// Waktu        : 18:30 PM

/* Effek dari operator ++ */
public class Incr {
/**
* @param args
*/
public static void main(String[] args) {
// TODO Auto-generated method stub
/* Kamus */
int i, j;
/* Program */
i = 3;
j = i++;
System.out.println ("Nilai i : " + (++i) +
"\nNilai j : " + j);
}
}