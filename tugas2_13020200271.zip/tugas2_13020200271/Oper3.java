//NIM           : 13020200271
//Nama          : Izzahra Zalzabila
// Tanggal/Hari : Selasa, 22 Maret 2022
// Waktu        : 18:30 PM

public class Oper3 {
/**
* @param args
*/
public static void main(String[] args) {
// TODO Auto-generated method stub
/* Algoritma */
if (true && true){ System.out.println(true && true); }
/* true = true and true */
if (true & true) { System.out.println(true & false); } /*
true & true */
if (true) { System.out.println(true); } /* true
*/
if (true || true){ System.out.println(true); } /* true
= true or true */
if (true|false) { System.out.println(true|false); } /*
true|false */
}
}