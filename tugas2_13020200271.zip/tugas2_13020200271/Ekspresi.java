//NIM           : 13020200271
//Nama          : Izzahra Zalzabila
// Tanggal/Hari : Selasa, 22 Maret 2022
// Waktu        : 18:30 PM

/* pemakaian operator kondisional */
public class Ekspresi {
/**
* @param args
*/
public static void main(String[] args) {
// TODO Auto-generated method stub
/* KAMUS */
int x = 1;
int y = 2;
/* ALGORITMA */
System.out.print("x = "+ x + "\n");
System.out.print("y = "+ y + "\n");
System.out.print("hasil ekspresi = (x<y)?x:y = "+ ((x < y) ?
x : y)); /*Gunakan dalam kurung "(statemen dan kondisi)" untuk menyatakan
satu kesatuan pernyataan*/
}
}