//NIM           : 13020200271
//Nama          : Izzahra Zalzabila
// Tanggal/Hari : Selasa, 22 Maret 2022
// Waktu        : 18:30 PM

public class ForEver {
/**
* @param args
*/
public static void main(String[] args) {
// TODO Auto-generated method stub
/* Program */
System.out.println("Program akan looping, akhiri dengan ^c");
while (true)
{ 
System.out.print ("Print satu baris ....\n");

}
}
}