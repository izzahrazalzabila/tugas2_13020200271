//NIM           : 13020200271
//Nama          : Izzahra Zalzabila
// Tanggal/Hari : Selasa, 22 Maret 2022
// Waktu        : 18:30 PM

import java.util.Scanner;
public class BacaData{

public static void main(String[] args) {
int a;
Scanner masukan;
System.out.print ("Contoh membaca dan menulis, ketik nilai integer: \n");
masukan = new Scanner(System.in);
a = masukan.nextInt(); 
System.out.print ("Nilai yang dibaca : "+ a);
}
}