//NIM           : 13020200271
//Nama          : Izzahra Zalzabila
// Tanggal/Hari : Selasa, 22 Maret 2022
// Waktu        : 18:30 PM

/* Eksrpesi kondisional dengan boolean */
public class KasusBoolean {
/**
* @param args
*/
public static void main(String[] args) {
// TODO Auto-generated method stub
/* Kamus */
boolean bool;
/* Algoritma */
bool= true;
if(bool) {
System.out.print("true\n");
} else
System.out.print("false\n");
if(!bool) {
System.out.print("salah\n");
} else
System.out.print("benar\n");
}
}