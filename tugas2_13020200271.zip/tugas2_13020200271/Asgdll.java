// NIM : 13020200271
//NAMA : Izzahra Zalzabila
// HARI/TANGGAL :Selasa, 22 Maret 2022
// WAKTU : 18.10 PM

public class Asgdll {

public static void main(String[] args) {

      float f= 20.0f;
       double fll;

       fll=10.0f;
System.out.println ("f : "+f +"\nf11: "+fll);
}
}