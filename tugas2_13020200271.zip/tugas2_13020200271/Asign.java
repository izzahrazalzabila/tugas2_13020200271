//NIM           : 13020200271
//Nama          : Izzahra Zalzabila
// Tanggal/Hari : Selasa, 22 Maret 2022
// Waktu        : 18:20 PM

public class Asign {
/**
* @param args
*/
public static void main(String[] args) {
// TODO Auto-generated method stub
/* Kamus */
int i;
/* Program */
System.out.print ("hello\n"); i = 5;
System.out.println ("Ini nilai i :" + i);
}
}