//NIM           : 13020200271
//Nama          : Izzahra Zalzabila
// Tanggal/Hari : Selasa, 22 Maret 2022
// Waktu        : 18:30 PM

public class ASIGNi {

public static void main(String[] args) {

short ks = 1;
int ki = 1;
long kl = 10000;
char c = 65; 
char c1 = 'Z'; 
double x = 50.2f;
float y = 50.2f;

System.out.println ("Karakter = "+ c);
System.out.println ("Karakter = "+ c1);

System.out.println ("Karakter = "+ c);
System.out.println ("Karakter = "+ c1);
System.out.println ("Bilangan integer (short) = "+ ks);
System.out.println ("\t(int) = "+ ki);
System.out.println ("\t(long)= "+ kl);
System.out.println ("Bilangan Real x = "+ x);
System.out.println ("Bilangan Real y = "+ y);
}
}